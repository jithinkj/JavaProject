package first;

import second.AcEx1;

public class AcEx2 extends AcEx1 {
    int j;

    public static void main(String[] args) {
        AcEx2 ab=new AcEx2();
        ab.a=2;

    }



}
