package first;

import java.util.ArrayList;

public class Employee {

    public Employee(String empName, float salary, String dept) {
        this.empName = empName;
        this.salary = salary;
        this.dept = dept;
    }

    public Employee() {
    }

    String empName;
    float salary;
    String dept;


}
