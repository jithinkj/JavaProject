package test;
import second.Department;
//public class Test {
//    public static void main(String[] args) {
//        Department d= new Department(5,"CSE");
//        d.details();
//    }
//}
