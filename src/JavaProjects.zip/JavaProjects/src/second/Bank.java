package second;

public class Bank  {
    int id;
    String code;

    public Bank(int id, String code) {
        this.id = id;
        this.code = code;
    }
}
