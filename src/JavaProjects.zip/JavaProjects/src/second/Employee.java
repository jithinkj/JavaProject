//package second;
//
//import java.util.Scanner;
//
//public class Employee {
//    public int add(int x, int y){
//    return x+y;
//    }
//    public static void main(String[] args) {
//        Department d= new Department(1,"ME");
//        d.details();
//        Scanner scan = new Scanner(System.in);
//        System.out.print("Enter value : ");
//        int a=scan.nextInt();
//        System.out.print("Enter value : ");
//        int b=scan.nextInt();
//        Employee e =new Employee();
//        System.out.println(e.add(a,b));
////        System.out.print("Enter string : ");
////        String s=scan.nextLine();
////        System.out.println("Entered string is "+s);
//    }
//}
